import numpy as np

from dkcmodels.graph.AdjacencyConfusion import AdjacencyConfusion
from dkcmodels.graph.ArrowConfusion import ArrowConfusion
from dkcmodels.graph.SHD import SHD
from dkcmodels.search.ScoreBased.DKC import dkc
from dkcmodels.utils.DAG2CPDAG import dag2cpdag
from dkcmodels.utils.TXT2GeneralGraph import txt2generalgraph


dataset = np.load('data15.npy')
Record = dkc(dataset, 'local_score_BIC', None, None)
est = Record['G']

truth_dag = txt2generalgraph("data15.graph.txt")
truth_cpdag = dag2cpdag(truth_dag)

adj = AdjacencyConfusion(truth_cpdag, est)
arrow = ArrowConfusion(truth_cpdag, est)

arrowsTp = arrow.get_arrows_tp()
arrowsFp = arrow.get_arrows_fp()
arrowsFn = arrow.get_arrows_fn()

adjRec = adj.get_adj_recall()
adjFDR = adj.get_adj_FDR ()

arrowRec = arrow.get_arrows_recall()
arrowFDR = arrow.get_arrows_FDR()

print(f"ArrowsTp: {arrowsTp}")
print(f"ArrowsFp: {arrowsFp}")
print(f"ArrowsFn: {arrowsFn}")

print(f"AdjTPR: {adjRec}")
print(f"AdjFDR: {adjFDR}")

shd = SHD(truth_cpdag, est)
print(f"SHD: {shd.get_shd()}")
print(f"ArrowTPR: {arrowRec}")
print(f"ArrowFDR: {arrowFDR}")